---
layout: post
title: "Sample Link Post"
description: "Example and code for using link posts."
tags: [sample post, link post]
comments: true
link: http://aronbordin.com
categories: [intro]
---

This theme supports **link posts**, made famous by John Gruber. To use, just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done.
